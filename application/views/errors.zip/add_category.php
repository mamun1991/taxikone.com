<?php include 'header.php'; ?>





<div class="container pt-5">

    <?php if ($error=$this->session->flashdata('msg1')) {?>

      <div class="row">

        <div class="col-lg-6">

          <div class="alert alert-Success">

            <?php echo $error;?>

          </div>

        </div>

      </div>

  <?php  } ?>



    <?php if ($error=$this->session->flashdata('msg')) {?>

      <div class="row">

        <div class="col-lg-6">

          <div class="alert alert-danger">

            <?php echo $error;?>

          </div>

        </div>

      </div>

  <?php  } ?>

</div>

<div class="container pt-5">
<h4 class="pt-4 ">
  <button class="btn btn-primary"><a style="color:white;" href="<?php echo base_url('Main/hotel_view') ?>" >Hotel</a></button>
  <button class="btn btn-success"><a style="color:white;" href="<?php echo base_url('Main/dest_view') ?>" >Destination</a></button>
  <button class="btn btn-warning"><a style="color:white;" href="<?php echo base_url('Main/drive_view') ?>" >Driver</a></button>
  <button class="btn btn-danger"><a style="color:white;" href="<?php echo base_url('Main/com_view') ?>" >Commission</a></button>
   <button class="btn btn-primary"><a style="color:white;" href="<?php echo base_url('Main/cate_page') ?>" >Add category</a></button>

   <button class="btn btn-success"><a style="color:white;" href="<?php echo base_url('Main/cate_hotel') ?>" >Add Hotel In Category</a></button>
    <button class="btn btn-warning"><a style="color:white;" href="<?php echo base_url('Main/show_cate_hotel') ?>" >Show  Hotel by Category</a></button>
</h4>




	

<form method="post" action="<?php echo base_url('Main/add_category') ?>">

  <div class="form-group">

    <label for="exampleInputEmail1"><strong>New category</strong></label>

    <input type="text" class="form-control" name="category"  placeholder="Enter category Name">

   

  </div>

<div class="form-group form-check">

  </div>

  <button type="submit" class="btn btn-primary">Add category</button>

</form>



</div>




<div class="container pt-5">

   

  <table class="table table-striped"><thead style="

    background-color: cornflowerblue;

">

    <tr>

      <th scope="col">#</th>

      <th scope="col">categries</th>

      <th scope="col">Delete</th>

    </tr>

  </thead>

  <tbody>

<?php 
$i=1;
foreach ($cate as $key ) {?>

  <tr>

    <td><?php echo $i; ?></td>

     <td>

       <?php echo $key->category_name; ?>

     </td>

      <td>  <a href="<?php echo base_url();?>Main/Delete_category/<?php echo $key->id;?>">Delete</a></td>

  </tr>

<?php $i++;}

 ?>



  </tbody>

</table>
<hr>
<form method="post" action="<?php echo base_url('Main/manager_category') ?>">
<div class="pt-4"> <strong>
  Assign category to Manager
<strong/></div>
  <div class="form-group">

    <label for="exampleInputEmail1"><strong>Category</strong></label>

   <select class="form-control" name="cate_id">
     <?php foreach ($cate  as $key ) {?>
       <option value="<?php echo $key->id; ?>"><?php echo $key->category_name; ?></option>
     <?php } ?>
   </select>

   

  </div>

   <div class="form-group">

    <label for="exampleInputEmail1"><strong>User</strong></label>

    <select class="form-control" name="user_id">
     <?php foreach ($user  as $key ) {

      ?>

       <option value="<?php echo $key->id; ?>"><?php echo $key->username; ?></option>
     <?php } ?>
   </select>

   

  </div>

<div class="form-group form-check">

  </div>

  <button type="submit" class="btn btn-primary">Add Manager</button>

</form>

</div>
<div class="container pt-5">

   

  <table class="table table-striped"><thead style="

    background-color: cornflowerblue;

">

    <tr>

      <th scope="col">#</th>
    <th scope="col">User</th>
      <th scope="col">categries</th>

      

    </tr>

  </thead>

  <tbody>

<?php 
$i=1;
foreach ($man as $key ) {?>

  <tr>

    <td><?php echo $i; ?></td>

     <td>

       <?php    $CI =& get_instance();


$data = $CI->db->select('username')->where('id',$key->user_id)->get('users')->row(); 

echo $data->username;
?>


     </td>

      <td> <?php    $CI =& get_instance();


$data = $CI->db->select('category_name')->where('id',$key->cate_id)->get('category')->row(); 

echo $data->category_name;
?> </td>

  </tr>

<?php $i++;}

 ?>



  </tbody>

</table>
</div>